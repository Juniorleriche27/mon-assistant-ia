# FAQ pratique - Horizon Numérique

## Contacter le centre
Le secrétariat répond du lundi au vendredi, de 8h00 à 17h00. L’adresse de démonstration est secretariat@horizon.example. Ce domaine est fictif ; il ne permet pas de contacter un vrai centre.

## Matériel et modalités
Les séances sont proposées en ligne. Il faut un ordinateur portable, une connexion Internet et un navigateur récent. Un téléphone seul ne permet pas de réaliser tous les exercices. Les supports de cours sont fournis en PDF.

## Attestation
Une attestation de suivi peut être délivrée si le participant assiste à au moins 80 % des séances et si son projet final est validé. Cette attestation n’est pas présentée comme un diplôme d’État.

## Inscription
L’assistant informe à partir des documents. Le secrétariat valide les inscriptions, les règlements et les demandes de report. L’assistant ne peut ni réserver une place ni effectuer un paiement.
