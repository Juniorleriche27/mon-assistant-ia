import './globals.css';
import type { ReactNode } from 'react';
export const metadata = { title: 'Horizon Numérique | Assistant documentaire', description: 'Les informations du centre, avec leurs sources.' };
export default function Layout({ children }: { children: ReactNode }) {
  return <html lang="fr"><body><header><a className="brand" href="/">HORIZON<span> NUMÉRIQUE</span></a><nav><a href="/">Assistant</a><a href="/admin">Administration</a></nav></header>{children}<footer>Projet pédagogique fictif · Assistant documentaire avec Cohere</footer></body></html>;
}
