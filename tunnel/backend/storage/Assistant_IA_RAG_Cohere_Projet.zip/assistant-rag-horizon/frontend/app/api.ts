export async function api(path: string, options: RequestInit = {}) {
  const response = await fetch(`/api${path}`, {
    ...options,
    cache: 'no-store',
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = Array.isArray(data.detail)
      ? data.detail.map((e: { msg: string }) => e.msg).join(', ')
      : data.detail;
    throw new Error(
      detail || `Service indisponible (HTTP ${response.status}).`
    );
  }
  return data;
}
export type Source = {
  id: string;
  document_id: string;
  filename: string;
  page: number | null;
  section: string | null;
  excerpt: string;
};
export type Answer = {
  request_id: string;
  answer: string;
  status: 'answered' | 'clarify' | 'not_found';
  sources: Source[];
};
