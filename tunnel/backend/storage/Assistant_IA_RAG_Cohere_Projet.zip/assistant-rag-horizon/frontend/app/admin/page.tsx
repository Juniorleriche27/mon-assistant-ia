'use client';
import { FormEvent, useState } from 'react';
import { api } from '../api';
type Doc = { id: string; filename: string; chunk_count: number; content_hash: string };
export default function Admin() {
  const [key,setKey]=useState(''); const [docs,setDocs]=useState<Doc[]>([]);
  const [busy,setBusy]=useState(false); const [message,setMessage]=useState('');
  const [file,setFile]=useState<File|null>(null);
  async function refresh() { setDocs(await api('/documents')); }
  async function action(job:()=>Promise<unknown>, success:string) {
    setBusy(true);setMessage('');
    try { await job(); await refresh(); setMessage(success); }
    catch(e) { setMessage(e instanceof Error?e.message:'L’opération a échoué.'); }
    finally {setBusy(false);}
  }
  function upload(e:FormEvent) {
    e.preventDefault(); if(!file)return;
    if(file.size>10*1024*1024){setMessage('La limite est de 10 Mo.');return;}
    const data=new FormData(); data.append('file',file);
    void action(()=>api('/admin/documents',{method:'POST',headers:{'X-Admin-Key':key},body:data}),'Document indexé.');
  }
  return <main className="admin"><div className="eyebrow">GESTION DOCUMENTAIRE</div><h1>Les bonnes<br/><span>informations.</span></h1><p className="lead">Ajoutez les documents validés par le centre et retirez les anciennes informations.</p>
    <section className="panel"><label htmlFor="admin-key">Clé d’administration</label><input id="admin-key" type="password" autoComplete="off" value={key} onChange={e=>setKey(e.target.value)} placeholder="Clé conservée uniquement pendant cette visite"/><div className="actions"><button disabled={busy} onClick={()=>void action(refresh,'Liste actualisée.')}>Actualiser la liste</button><button disabled={busy||!key} onClick={()=>void action(()=>api('/admin/seed',{method:'POST',headers:{'X-Admin-Key':key}}),'Corpus de référence indexé.')}>Indexer le corpus initial</button></div></section>
    <section className="panel"><h2>Ajouter ou remplacer un document</h2><form onSubmit={upload}><input aria-label="Choisir un document" type="file" accept=".pdf,.md,.txt" onChange={e=>setFile(e.target.files?.[0]||null)}/><button className="primary" disabled={busy||!key||!file}>Indexer le document</button></form><p className="hint">PDF texte, Markdown ou TXT · 10 Mo maximum · Un fichier de même nom remplace la version précédente.</p></section>
    {message&&<p role="status" className="notice">{message}</p>}
    <section className="panel"><h2>Documents indexés</h2>{docs.length===0?<p>Aucun document affiché. Actualisez la liste.</p>:<ul className="documents">{docs.map(d=><li key={d.id}><div><a href={`/api/documents/${d.id}/download`}>{d.filename}</a><small>{d.chunk_count} fragments · version {d.content_hash.slice(0,8)}</small></div><button disabled={busy||!key} onClick={()=>{if(window.confirm(`Retirer ${d.filename} du corpus ?`))void action(()=>api(`/admin/documents/${d.id}`,{method:'DELETE',headers:{'X-Admin-Key':key}}),'Document retiré.');}}>Retirer</button></li>)}</ul>}</section>
  </main>;
}
