'use client';
import { FormEvent, useRef, useState } from 'react';
import { api, Answer } from './api';
type Entry = { question: string; result: Answer; feedback?: boolean };
const prompts = ['Quel est le tarif de la formation Analyse de Données ?', 'Quels sont les horaires des cours du soir ?', 'Comment se déroule une inscription ?'];
export default function Home() {
  const [question, setQuestion] = useState('');
  const [entries, setEntries] = useState<Entry[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const input = useRef<HTMLTextAreaElement>(null);
  async function ask(value: string) {
    if (!value.trim() || busy) return;
    setBusy(true); setError('');
    try {
      const history = entries.slice(-3).flatMap(e => [{ role:'user', content:e.question.slice(0,2000) }, { role:'assistant', content:e.result.answer.slice(0,2000) }]);
      const result = await api('/chat', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({question:value.trim(),history}) });
      setEntries(old => [...old,{question:value.trim(),result}]); setQuestion('');
    } catch (e) { setError(e instanceof Error ? e.message : 'La demande a échoué.'); }
    finally { setBusy(false); input.current?.focus(); }
  }
  function submit(e: FormEvent) { e.preventDefault(); void ask(question); }
  async function feedback(index: number, useful: boolean) {
    try {
      await api('/feedback',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({request_id:entries[index].result.request_id,useful})});
      setEntries(old => old.map((item,i) => i===index ? {...item,feedback:true} : item));
    } catch(e) { setError(e instanceof Error ? e.message : 'Avis non enregistré.'); }
  }
  return <main className="home"><div className="eyebrow">LE CENTRE, À VOTRE ÉCOUTE</div><h1>Une réponse.<br/><span>Sa source.</span></h1><p className="lead">Formations, tarifs, inscriptions : posez votre question et consultez les documents à l’origine de la réponse.</p>
    <section className="conversation" aria-label="Conversation">
      {entries.length===0 && <div className="welcome"><div className="badge">H</div><div><h2>Bonjour, comment puis-je vous aider ?</h2><p>Choisissez une question ou écrivez la vôtre.</p></div></div>}
      {entries.length===0 && <div className="suggestions">{prompts.map(p => <button key={p} disabled={busy} onClick={()=>void ask(p)}>{p}<span aria-hidden="true"> ↗</span></button>)}</div>}
      {entries.map((entry,index)=><article key={entry.result.request_id}>
        <p className="question"><span className="sr-only">Vous : </span>{entry.question}</p>
        <div className="answer"><div className="label">HORIZON · ASSISTANT</div><p>{entry.result.answer}</p>
          {entry.result.status==='not_found' && <div className="notice">Information non confirmée dans les documents disponibles.</div>}
          {entry.result.status==='clarify' && <div className="notice">Une précision permettra de mieux vous répondre.</div>}
          {entry.result.sources.length>0 && <details><summary>{entry.result.sources.length} source(s) à consulter</summary>{entry.result.sources.map((s,i)=><div className="source" key={s.id}><a href={`/api/documents/${s.document_id}/download`}>[{i+1}] {s.filename}</a><small>{s.page ? `Page ${s.page}` : s.section}</small><p>{s.excerpt}</p></div>)}</details>}
          <div className="feedback">{entry.feedback ? 'Merci pour votre retour.' : <><span>Cette réponse vous aide ?</span><button onClick={()=>void feedback(index,true)}>Oui</button><button onClick={()=>void feedback(index,false)}>À revoir</button></>}</div>
        </div></article>)}
      {busy && <p role="status" className="loading">Recherche dans les documents…</p>}
      {error && <p className="error" role="alert">{error}</p>}
      <form onSubmit={submit}><label htmlFor="question" className="sr-only">Votre question</label><textarea id="question" ref={input} maxLength={1500} value={question} onChange={e=>setQuestion(e.target.value)} placeholder="Écrivez votre question…" rows={2} disabled={busy}/><button className="primary" disabled={busy||!question.trim()} type="submit">{busy?'Recherche…':'Envoyer ↗'}</button></form>
      <p className="hint">Les informations affichées dépendent des documents du centre. Pour une situation personnelle, contactez le secrétariat.</p>
    </section></main>;
}
