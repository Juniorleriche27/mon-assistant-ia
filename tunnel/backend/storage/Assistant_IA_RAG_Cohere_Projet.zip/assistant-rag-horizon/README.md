# Horizon Numérique - projet du livre, édition Cohere

Assistant documentaire : FastAPI, Next.js, PostgreSQL/pgvector, Cohere Chat et Embed v2.
Les documents du centre sont entièrement fictifs. Le projet ne dépend pas d’OpenAI.

## Démarrage recommandé avec Docker

Préparer Python 3.12, Docker avec Compose v2 et un éditeur de texte.

```bash
python scripts/setup_env.py
```

Ouvrir le fichier local `.env` et renseigner `COHERE_API_KEY`. Le script a généré les secrets de base et d’administration sans les afficher. Conserver ce fichier sur sa machine. Les modèles de référence sont `command-r7b-12-2024` et `embed-v4.0` en 1024 dimensions.

```bash
docker compose up --build
```

Ouvrir http://localhost:3000/admin, saisir la valeur locale `ADMIN_API_KEY`, puis cliquer sur « Indexer le corpus initial ». Ouvrir ensuite http://localhost:3000. La liste publique des documents est visible via http://localhost:8000/documents ; l’état du serveur via http://localhost:8000/health.

Un démarrage sans clé reste utile pour inspecter l’interface. L’indexation et la génération demandent une clé Cohere ; aucun faux modèle ne remplace silencieusement le fournisseur.

## Développement local sans Docker

Le stockage SQLite est une variante de développement et de tests. Il n’active ni pgvector ni la recherche plein texte PostgreSQL. Les appels IA restent de vrais appels Cohere si une clé est configurée.

```bash
python -m venv .venv
# Activer .venv : Windows .venv\Scripts\activate ; Linux source .venv/bin/activate
python -m pip install -r backend/requirements.txt
```

Dans `.env`, utiliser `DATABASE_URL=sqlite:///local.db` pour ce mode. Depuis la racine, sous PowerShell :

```powershell
$env:PYTHONPATH = "backend"
python -m uvicorn app.main:create_app --factory --host 127.0.0.1 --port 8000
```

Sous Bash :

```bash
PYTHONPATH=backend python -m uvicorn app.main:create_app --factory --host 127.0.0.1 --port 8000
```

Dans un second terminal :

```bash
cd frontend
npm ci
npm run dev
```

## Tests sans clé API

```bash
python -m unittest discover -s tests -v
cd frontend
npm ci
npm run build
npm audit --omit=dev
```

Les tests logiciels emploient SQLite et des doubles de test Cohere, dont un transport HTTP simulé. Ils vérifient la logique et le contrat des requêtes, pas la qualité réelle des modèles ou le déploiement Docker.

## Évaluation avec Cohere

Après indexation, exporter `ADMIN_API_KEY` dans l’environnement du terminal de travail puis :

```bash
python eval/run_eval.py --base-url http://localhost:8000 --interval 15
```

Le jeu comprend 35 questions. Adapter l’intervalle aux quotas en vigueur du compte. Le rapport sépare les critères automatiques et les sources ; une lecture humaine vérifie les conditions, les négations et les exceptions. La consommation affichée concerne la génération ; les embeddings doivent être comptés séparément.

## Production

Configurer `DOMAIN` dans `.env`, faire pointer le DNS vers le serveur et rendre les ports 80/443 accessibles à Caddy. Employer le fichier complet de production, sans le fusionner avec celui de développement :

```bash
docker compose -f docker-compose.prod.yml up -d --build
```

Le backend et la base ne publient pas de port en production. Caddy retire `/api` avant de transmettre la requête à FastAPI. L’adresse interne du proxy est fixée à `172.29.77.10` et constitue la seule adresse de proxy autorisée à transmettre l’IP visiteur. Si le sous-réseau est déjà utilisé, changer ensemble le réseau, l’IP Caddy et `FORWARDED_ALLOW_IPS`.

Les originaux des documents sont stockés dans la base avec leurs fragments. Le dump sauvegarde donc aussi ces fichiers. Les secrets `.env`, le code et les volumes de certificats Caddy restent à sauvegarder selon une procédure distincte et adaptée.

```bash
chmod +x scripts/*.sh
./scripts/backup_db.sh
./scripts/restore_db.sh backups/nom_du_fichier.sql.gz rag_restore_verification
```

La restauration crée une nouvelle base et s’arrête sur une erreur SQL. Elle ne remplace pas la base active. Le nom doit commencer par `rag_restore_`. Inspecter cette nouvelle base et les résultats de recherche avant toute décision de bascule. Le fichier `deploy/backup.cron.example` propose une planification à adapter sur le serveur.

## Coûts et clé d’essai

Cohere distingue les clés d’évaluation gratuites avec limites et les clés de production payantes. Le chapitre 12 et les modèles client distinguent ces usages. Les prix et limites sont à relever dans le compte et la documentation à la date du devis.

## Arborescence

- `backend/app/` : configuration, stockage, ingestion, Cohere, RAG et API.
- `frontend/` : discussion et administration Next.js.
- `corpus/` : quatre PDF et une FAQ Markdown fictifs.
- `eval/` : 35 cas et un évaluateur automatique.
- `tests/` : tests logiciels sans appel facturé.
- `scripts/` : configuration, corpus, sauvegarde, restauration et coûts.
- `modeles_clients/` : cahier des charges, devis, réception et évaluation.
- `book/` : manuscrit et références de l’édition Cohere.
- `VALIDATION.md` : résultats effectivement vérifiés et contrôles restant à réaliser.

## Reconstruire le livre

Depuis la racine :

```bash
python -m pip install -r requirements-editorial.txt
python scripts/build_manuscript.py
python scripts/render_book.py
```

Les polices et leur notice sont fournies dans `assets/fonts/`. Les extraits du manuscrit sont récupérés depuis les fichiers du projet pour rester cohérents avec le code.

