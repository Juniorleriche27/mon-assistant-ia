# Évaluation et coûts - version Cohere

## Évaluation manuelle

| ID | Statut attendu | Réponse correcte et complète ? | Passage exact pertinent ? | Conditions et exceptions conservées ? | Correction |
|---|---|---|---|---|---|
| Q01 | answered | | | | |
| Q14 | answered | | | | |
| Q26 | clarify | | | | |
| Q29 | not_found | | | | |

Le rapport automatique mesure des indicateurs. La présence d’un mot ne suffit pas à prouver l’exactitude. Une réponse « Python obligatoire » ne valide pas un cas où aucun prérequis n’est demandé. Une réponse de refus peut rappeler un montant sans l’accorder.

## Calcul des coûts

C_chat = (jetons_entree * prix_entree_par_million + jetons_sortie * prix_sortie_par_million) / 1_000_000

C_embed = jetons_embeddings * prix_embeddings_par_million / 1_000_000

C_total = C_chat + C_embed + hébergement + domaine + sauvegardes + maintenance

Renseigner séparément les entrées, les sorties, l’indexation des documents et les embeddings de requêtes. Indiquer la devise et la date des prix. Utiliser le script scripts/costs.py pour les calculs. Les quotas d’essai ne constituent pas un budget d’exploitation commerciale.
