# Fiche de Réception et Remise Client

**Projet :** Assistant IA Documentaire — [Nom du client]  
**Date de livraison :** [JJ/MM/AAAA]  
**URL de production :** [https://assistant.client.com]

## 1. Vérification des livrables techniques
- [ ] Interface visiteur accessible en HTTPS sur ordinateur et mobile.
- [ ] Espace administrateur (`/admin`) accessible et protégé par clé.
- [ ] Corpus initial indexé (`[X]` documents actifs).
- [ ] Jeu d'évaluation exécuté (`[X / X]` questions validées).
- [ ] Sauvegarde automatique et test de restauration vérifiés.

## 2. Éléments remis au client
- [ ] Identifiant et clé d'accès à l'espace administrateur (transmis par canal sécurisé).
- [ ] Accès au dépôt de code et aux variables d'environnement de production.
- [ ] Guide rapide d'utilisation pour mettre à jour un PDF dans `/admin`.

## 3. Validation
Le client reconnaît avoir assisté à la démonstration de fonctionnement sur les questions convenues au cahier des charges et prononce la réception du projet.

**Pour le client :** ________________________ (Nom, date et signature)  
**Pour le prestataire :** ___________________ (Nom, date et signature)
