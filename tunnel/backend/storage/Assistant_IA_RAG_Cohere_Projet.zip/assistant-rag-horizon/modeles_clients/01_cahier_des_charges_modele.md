# Modèle de Cahier des Charges — Assistant IA Documentaire (1 page)

**Client :** [Nom de l'organisation]  
**Prestataire :** [Votre nom / Studio]  
**Date :** [JJ/MM/AAAA]

## 1. Objectif du projet
Mettre en place un assistant conversationnel web permettant aux [visiteurs / clients / collaborateurs] d'obtenir des réponses fiables et sourcées à partir des documents officiels de l'organisation.

## 2. Périmètre documentaire (sources de vérité)
- **Documents inclus :** [Ex. Catalogue PDF, Grille tarifaire, Règlement, FAQ]
- **Personne référente pour la validation des documents :** [Nom et fonction]
- **Documents exclus (hors périmètre) :** [Ex. Documents scannés non OCRisés, dossiers confidentiels RH]

## 3. Parcours utilisateurs
- **Visiteur :** Pose une question via l'interface web, consulte la réponse et les extraits sources cités, signale si la réponse est utile ou à revoir.
- **Administrateur :** Accède à l'espace protégé (`/admin`) pour ajouter, remplacer ou supprimer un document.

## 4. Règles de comportement attendues
- Répondre uniquement à partir des documents indexés.
- Citer le document et la page source, ou la section pour un fichier Markdown.
- En cas d'absence d'information : indiquer clairement l'absence de réponse et orienter vers `[email ou téléphone de contact]`.

## 5. Critères de réussite mesurables (recette)
- Score minimum sur le jeu de test de référence (`[30]` questions) : `[>= 90 %]` de réponses exactes et sourcées.
- Aucune information inventée observée sur le jeu hors périmètre convenu ; conserver les résultats détaillés.
- Temps de réponse moyen inférieur à `[4]` secondes.
