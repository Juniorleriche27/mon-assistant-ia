# Modèle de Proposition Commerciale et Devis — Assistant IA RAG

**Client :** [Nom du client]  
**Référence :** DEV-RAG-[AAAA-001]  
**Validité :** 30 jours

## 1. Prestation de réalisation (forfait unique)

| Poste | Détail de la prestation | Montant HT |
| :--- | :--- | ---: |
| **1. Cadrage & corpus** | Atelier de cadrage, collecte et nettoyage des documents initiaux, création du jeu de 30 questions de test. | [XXX] € |
| **2. Moteur RAG & API** | Déploiement PostgreSQL (`pgvector`), pipeline d'ingestion avec provenance, recherche hybride et API FastAPI sécurisée. | [XXX] € |
| **3. Interface web & Admin** | Personnalisation aux couleurs du client (logo, couleurs), interface de chat visiteur et espace `/admin`. | [XXX] € |
| **4. Tests, mise en ligne & remise** | Exécution du rapport d'évaluation, mise en production HTTPS, sauvegardes automatiques et formation de prise en main (1 h). | [XXX] € |
| **Total réalisation** | | **[TOTAL] €** |

## 2. Services externes (à la charge directe du client)
- **Hébergement serveur VPS (Docker) :** [Montant vérifié] / mois (hébergeur et date à préciser).
- **Nom de domaine :** [Montant vérifié] / an.
- **Consommation API IA (Cohere) :** facturation directe à l'usage (montant calculé selon les volumes et tarifs du compte).

## 3. Maintenance et suivi (optionnel — abonnement mensuel)
- **Forfait mensuel ([XX] € / mois) :** Surveillance de disponibilité, vérification des sauvegardes, analyse mensuelle des retours négatifs (`/feedback`) et ajustement des consignes ou du découpage si de nouveaux types de documents sont ajoutés.

## 4. Modalités de règlement
- `40 %` à la signature du devis, `60 %` à la signature de la fiche de réception.

## Hypothèses de chiffrage
Préciser la monnaie, le nombre de questions, les jetons d’entrée et de sortie, les jetons d’embeddings, les prix unitaires vérifiés et leur date. La clé Cohere d’essai concerne le prototype ; le devis d’exploitation utilise les conditions du compte de production.
