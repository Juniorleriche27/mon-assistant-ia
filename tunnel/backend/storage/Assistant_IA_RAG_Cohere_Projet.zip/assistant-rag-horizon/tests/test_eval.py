import importlib.util
import unittest
from pathlib import Path

def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
ROOT=Path(__file__).resolve().parents[1]
evaluation=load('evaluation',ROOT/'eval/run_eval.py')
costs=load('costs',ROOT/'scripts/costs.py')


class EvaluationTests(unittest.TestCase):
 def test_ambiguous_question_cannot_pass_with_price_only(self):
  case={'expected_status':'clarify','required_groups':[['quelle formation','préciser']]}
  answer={'status':'answered','answer':'650 euros','sources':[]}
  self.assertFalse(evaluation.judge(case,answer)['automatic_pass'])
 def test_refusal_can_repeat_a_forbidden_discount(self):
  case={'expected_status':'not_found'}
  answer={'status':'not_found','answer':'Je ne peux pas accorder une réduction de 90 %.','sources':[]}
  self.assertTrue(evaluation.judge(case,answer)['automatic_pass'])
 def test_cross_source_case_requires_all_sources(self):
  case={'expected_status':'answered','required_sources':['a.pdf','b.pdf']}
  answer={'status':'answered','answer':'texte','sources':[{'filename':'a.pdf'}]}
  self.assertFalse(evaluation.judge(case,answer)['automatic_pass'])
 def test_independent_cost_components(self):
  actual=costs.calculate(2_000_000,500_000,1_000_000,1,2,0.1,10)
  self.assertAlmostEqual(actual['total'],13.1)
 def test_negative_cost_rejected(self):
  with self.assertRaises(ValueError):costs.calculate(-1,0,0,1,1,1)

