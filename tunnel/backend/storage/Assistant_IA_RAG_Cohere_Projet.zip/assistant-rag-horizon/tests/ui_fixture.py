"""Serveur de test visuel local. Les réponses sont simulées ; aucune API appelée."""
from pathlib import Path
import sys
import tempfile
import uvicorn
sys.path.insert(0,str(Path(__file__).resolve().parent))
from test_backend import FakeProvider
from app.config import Settings
from app.db import Store
from app.ingestion import ingest
from app.main import create_app

temp=tempfile.TemporaryDirectory()
settings=Settings(_env_file=None,database_url=f'sqlite:///{temp.name}/ui.db',embedding_dimension=256,
                  admin_api_key='ui-test-key',chat_limit_per_minute=1000)
database=Store(settings.database_url,256);database.initialize()
provider=FakeProvider(256)
for file in (Path(__file__).resolve().parents[1]/'corpus').iterdir():
    if file.suffix in ('.pdf','.md'):ingest(database,provider,settings,file.name,file.read_bytes())
app=create_app(settings,database,provider)
if __name__=='__main__':uvicorn.run(app,host='127.0.0.1',port=8000,log_level='warning')
