import gzip
import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


@unittest.skipUnless(shutil.which('bash') and shutil.which('gzip'),'Bash et gzip requis')
class ScriptTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
  (self.root/'scripts').mkdir();(self.root/'bin').mkdir()
  for name in ['backup_db.sh','restore_db.sh']:
   shutil.copyfile(ROOT/'scripts'/name,self.root/'scripts'/name)
  self.env={**os.environ,'PATH':str(self.root/'bin')+os.pathsep+os.environ['PATH']}
 def tearDown(self):self.temp.cleanup()
 def docker(self,body):
  p=self.root/'bin/docker';p.write_text('#!/usr/bin/env bash\n'+body);p.chmod(0o700)
 def test_bash_syntax(self):
  for p in (self.root/'scripts').glob('*.sh'):
   self.assertEqual(subprocess.run(['bash','-n',str(p)],capture_output=True).returncode,0)
 def test_failed_backup_is_not_published(self):
  self.docker('exit 1\n')
  r=subprocess.run(['bash',str(self.root/'scripts/backup_db.sh')],env=self.env,capture_output=True)
  self.assertNotEqual(r.returncode,0);self.assertEqual(list((self.root/'backups').iterdir()),[])
 def test_successful_backup_is_valid_gzip(self):
  self.docker("printf 'SELECT 1;\\n'\n")
  r=subprocess.run(['bash',str(self.root/'scripts/backup_db.sh')],env=self.env,capture_output=True)
  self.assertEqual(r.returncode,0)
  files=list((self.root/'backups').glob('*.sql.gz'));self.assertEqual(len(files),1)
  with gzip.open(files[0]) as f:self.assertEqual(f.read(),b'SELECT 1;\n')
 def test_restore_requires_new_target_name(self):
  r=subprocess.run(['bash',str(self.root/'scripts/restore_db.sh'),'missing.sql.gz','production'],env=self.env,capture_output=True)
  self.assertNotEqual(r.returncode,0)
 def test_restore_stops_on_sql_error(self):
  backup=self.root/'valid.sql.gz'
  with gzip.open(backup,'wb') as f:f.write(b'INVALID SQL;\n')
  self.docker('''case "$*" in
    *createdb*) exit 0;;
    *ON_ERROR_STOP=1*) cat >/dev/null; exit 3;;
    *) exit 0;;
  esac
''')
  r=subprocess.run(['bash',str(self.root/'scripts/restore_db.sh'),str(backup),'rag_restore_test'],env=self.env,capture_output=True,text=True)
  self.assertNotEqual(r.returncode,0);self.assertNotIn('Restauration terminée',r.stdout)
