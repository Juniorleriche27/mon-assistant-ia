"""Mesure des indicateurs automatiques ; une lecture humaine reste nécessaire."""

import argparse
import json
import os
import re
import statistics
import sys
import time
import unicodedata
from pathlib import Path
import httpx


def norm(text):
    return "".join(
        c
        for c in unicodedata.normalize("NFKD", text.casefold())
        if not unicodedata.combining(c)
    )


def judge(case, answer, retrieved=None):
    text = norm(answer["answer"])
    sources = {s["filename"] for s in answer.get("sources", [])}
    status = answer["status"] == case["expected_status"]
    groups = case.get("required_groups", [])
    facts = all(
        any(norm(term) in text for term in group)
        for group in groups
    )
    forbidden = not any(
        re.search(pattern, text)
        for pattern in case.get("forbidden_patterns", [])
    )
    required_sources = set(case.get("required_sources", []))
    cited = (
        required_sources <= sources
        if case["expected_status"] == "answered"
        else not sources
    )
    retrieved_files = {r["filename"] for r in retrieved or []}
    retrieval = (
        (required_sources <= retrieved_files)
        if retrieved is not None and required_sources
        else None
    )
    return {
        "status_ok": status,
        "facts_proxy_ok": facts,
        "forbidden_claims_ok": forbidden,
        "citations_files_ok": cited,
        "retrieval_files_ok": retrieval,
        "automatic_pass": status and facts and forbidden and cited,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--base-url", default="http://localhost:8000"
    )
    parser.add_argument(
        "--questions",
        type=Path,
        default=Path(__file__).with_name(
            "questions_reference.json"
        ),
    )
    parser.add_argument(
        "--output", type=Path, default=Path("eval/report.json")
    )
    parser.add_argument(
        "--interval",
        type=float,
        default=15,
        help="Pause entre appels ; adapter aux quotas du compte.",
    )
    args = parser.parse_args()
    key = os.environ.get("ADMIN_API_KEY", "")
    if not key:
        raise SystemExit(
            "Définir ADMIN_API_KEY dans l’environnement du terminal"
            " pour évaluer /search."
        )
    cases = json.loads(args.questions.read_text())
    results = []
    with httpx.Client(
        base_url=args.base_url.rstrip("/"), timeout=60
    ) as client:
        for case in cases:
            search = client.post(
                "/search",
                json={"question": case["question"]},
                headers={"X-Admin-Key": key},
            )
            search.raise_for_status()
            time.sleep(max(0, args.interval))
            start = time.monotonic()
            response = client.post(
                "/chat", json={"question": case["question"]}
            )
            response.raise_for_status()
            answer = response.json()
            results.append(
                {
                    "id": case["id"],
                    "question": case["question"],
                    "answer": answer,
                    "seconds": time.monotonic() - start,
                    **judge(case, answer, search.json()),
                }
            )
            print(case["id"], results[-1]["automatic_pass"])
            time.sleep(max(0, args.interval))
    summary = {
        "cases": len(results),
        "automatic_pass": sum(r["automatic_pass"] for r in results),
        "mean_seconds": statistics.mean(
            r["seconds"] for r in results
        ),
        "chat_input_tokens": sum(
            r["answer"].get("usage", {}).get("input_tokens", 0)
            for r in results
        ),
        "chat_output_tokens": sum(
            r["answer"].get("usage", {}).get("output_tokens", 0)
            for r in results
        ),
        "interpretation": (
            "Indicateurs automatiques, à compléter par une lecture"
            " humaine. Jetons embeddings exclus."
        ),
        "results": results,
    }
    args.output.parent.mkdir(exist_ok=True, parents=True)
    args.output.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2)
    )
    return 0 if summary["automatic_pass"] == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
