from pathlib import Path
from pydantic import Field, SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", extra="ignore"
    )
    database_url: str = (
        "postgresql://rag_user:change-me@localhost:5432/rag_horizon"
    )
    cohere_api_key: SecretStr = SecretStr("")
    cohere_chat_model: str = "command-r7b-12-2024"
    cohere_embed_model: str = "embed-v4.0"
    embedding_dimension: int = Field(default=1024, ge=1, le=1536)
    admin_api_key: SecretStr = SecretStr("")
    allowed_origins: str = "http://localhost:3000"
    corpus_dir: Path = Path("corpus")
    max_upload_bytes: int = 10 * 1024 * 1024
    max_document_characters: int = 250_000
    chat_limit_per_minute: int = Field(default=20, ge=1, le=1000)
    minimum_similarity: float = Field(default=0.35, ge=-1, le=1)
    contact: str = "le secrétariat du centre"

    @model_validator(mode="after")
    def validate_embedding_configuration(self):
        if self.cohere_embed_model != "embed-v4.0":
            raise ValueError(
                "Cette édition utilise embed-v4.0. Un changement de"
                " modèle demande une migration et une réindexation."
            )
        if self.embedding_dimension not in (256, 512, 1024, 1536):
            raise ValueError(
                "Dimension non prise en charge pour embed-v4.0."
            )
        return self

    @property
    def embedding_identity(self):
        return (
            "cohere:"
            f"{self.cohere_embed_model}:"
            f"{self.embedding_dimension}:"
            "chunk-v1"
        )
