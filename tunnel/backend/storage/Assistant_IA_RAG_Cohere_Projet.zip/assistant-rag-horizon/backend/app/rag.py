import re
from .db import normalize


def obvious_override(question):
    """Repère minimal pour les essais ; ce filtre ne constitue pas une garantie."""
    q = normalize(question)
    return bool(
        re.search(
            r"(ignore|oublie).{0,30}(consigne|instruction)|cle"
            r" api|api key|system prompt",
            q,
        )
    )


def answer_question(store, provider, settings, question, history):
    def response(status, answer, sources=None, usage=None):
        return {
            "status": status,
            "answer": answer,
            "sources": sources or [],
            "usage": usage or {},
            "found_in_corpus": status == "answered",
        }

    if obvious_override(question):
        return response(
            "not_found",
            "Je peux vous informer à partir des documents du"
            " centre. Pour une demande particulière, contactez le"
            " secrétariat.",
        )
    if not store.documents():
        return response(
            "not_found",
            "Aucun document n’est encore indexé. Contactez le"
            " secrétariat.",
        )
    vector = provider.embed([question], "search_query")[0]
    chunks = store.search(
        question, vector, settings.embedding_identity
    )
    # Un seuil est un réglage à évaluer sur le corpus, jamais une preuve de vérité.
    if not chunks or not any(
        c["vector_score"] >= settings.minimum_similarity
        or c["keyword_score"] > 0
        for c in chunks
    ):
        return response(
            "not_found",
            "Je ne trouve pas cette information dans les"
            f" documents. Contactez {settings.contact}.",
        )
    generated, usage = provider.generate(question, chunks, history)
    known = {c["id"]: c for c in chunks}
    ids = list(dict.fromkeys(generated.source_ids))
    if generated.status == "answered" and (
        not ids or any(i not in known for i in ids)
    ):
        return response(
            "not_found",
            "Je ne peux pas relier cette réponse à une source"
            f" vérifiable. Contactez {settings.contact}.",
            usage=usage,
        )
    sources = []
    if generated.status == "answered":
        for source_id in ids:
            c = known[source_id]
            sources.append(
                {
                    "id": source_id,
                    "document_id": c["document_id"],
                    "filename": c["filename"],
                    "page": c["page"],
                    "section": c["section"],
                    "excerpt": c["content"],
                }
            )
    return response(
        generated.status, generated.answer, sources, usage
    )
