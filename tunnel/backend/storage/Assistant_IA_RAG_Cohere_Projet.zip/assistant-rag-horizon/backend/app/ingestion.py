import hashlib
import io
import re
from pathlib import Path
from pypdf import PdfReader


def safe_filename(filename):
    if (
        not filename
        or len(filename) > 180
        or any(ord(c) < 32 for c in filename)
    ):
        raise ValueError("Nom de fichier invalide.")
    if (
        "/" in filename
        or "\\" in filename
        or filename in (".", "..")
    ):
        raise ValueError(
            "Le nom doit désigner un fichier, sans chemin."
        )
    suffix = Path(filename).suffix.lower()
    if suffix not in (".pdf", ".md", ".txt"):
        raise ValueError(
            "Formats acceptés : PDF texte, Markdown et TXT."
        )
    return suffix


def split_into_chunks(text, size=750, overlap=120):
    """Découpage par paragraphes puis fenêtres si un paragraphe est trop long."""
    if size <= 0 or overlap < 0 or overlap >= size:
        raise ValueError("Paramètres de découpage incorrects.")
    text = text.replace("\r\n", "\n").strip()
    chunks, current = [], ""
    for paragraph in re.split(r"\n\s*\n", text):
        paragraph = paragraph.strip()
        if not paragraph:
            continue
        while len(paragraph) > size:
            if current:
                chunks.append(current)
                current = ""
            chunks.append(paragraph[:size])
            paragraph = paragraph[size - overlap :]
        proposed = (
            current + "\n\n" + paragraph if current else paragraph
        )
        if len(proposed) <= size:
            current = proposed
        else:
            chunks.append(current)
            tail = current[-overlap:] if overlap else ""
            current = (tail + "\n\n" + paragraph).strip()
            if len(current) > size:
                current = paragraph
    if current:
        chunks.append(current)
    return chunks


def extract_fragments(filename, data, settings):
    suffix = safe_filename(filename)
    if not data or len(data) > settings.max_upload_bytes:
        raise ValueError(
            "Fichier vide ou supérieur à la limite de taille."
        )
    fragments = []
    if suffix == ".pdf":
        if not data.startswith(b"%PDF-"):
            raise ValueError(
                "Le contenu ne correspond pas à un PDF."
            )
        try:
            reader = PdfReader(io.BytesIO(data))
            if reader.is_encrypted or len(reader.pages) > 200:
                raise ValueError(
                    "PDF chiffré ou supérieur à 200 pages."
                )
            for page_number, page in enumerate(reader.pages, 1):
                text = page.extract_text() or ""
                fragments.extend(
                    {
                        "page": page_number,
                        "section": None,
                        "content": c,
                    }
                    for c in split_into_chunks(text)
                )
        except ValueError:
            raise
        except Exception as error:
            raise ValueError("PDF illisible.") from error
    else:
        try:
            text = data.decode("utf-8-sig")
        except UnicodeDecodeError as error:
            raise ValueError(
                "Le fichier texte doit être encodé en UTF-8."
            ) from error
        if "\x00" in text:
            raise ValueError(
                "Un fichier binaire ne peut pas être traité comme"
                " du texte."
            )
        section, body = "Introduction", []

        def flush():
            fragments.extend(
                {"page": None, "section": section, "content": c}
                for c in split_into_chunks("\n".join(body))
            )

        for line in text.splitlines():
            if suffix == ".md" and re.match(r"^#{1,6}\s+", line):
                flush()
                section = re.sub(r"^#{1,6}\s+", "", line).strip()
                body = []
            else:
                body.append(line)
        flush()
    total = sum(len(f["content"]) for f in fragments)
    if not fragments or total < 20:
        raise ValueError(
            "Aucun texte exploitable. Un PDF scanné nécessite un"
            " OCR préalable."
        )
    if total > settings.max_document_characters:
        raise ValueError(
            "Le document contient trop de texte pour cette édition."
        )
    return fragments


def ingest(store, provider, settings, filename, data):
    fragments = extract_fragments(filename, data, settings)
    content_hash = hashlib.sha256(data).hexdigest()
    before = store.document_by_name(filename)
    if (
        before
        and before["content_hash"] == content_hash
        and before["embedding_identity"]
        == settings.embedding_identity
    ):
        return {
            "status": "unchanged",
            "document_id": before["id"],
            "chunks": before["chunk_count"],
        }
    vectors = provider.embed(
        [f["content"] for f in fragments], "search_document"
    )
    if len(vectors) != len(fragments):
        raise ValueError(
            "Le nombre de vecteurs et de fragments diffère."
        )
    for fragment, vector in zip(fragments, vectors):
        fragment["embedding"] = vector
    doc_id = store.replace_document(
        filename,
        content_hash,
        settings.embedding_identity,
        data,
        fragments,
        before["content_hash"] if before else None,
    )
    return {
        "status": "updated" if before else "created",
        "document_id": doc_id,
        "chunks": len(fragments),
    }
