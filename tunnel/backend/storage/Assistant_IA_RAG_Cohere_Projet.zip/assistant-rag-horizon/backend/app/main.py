import logging
import secrets
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal
from urllib.parse import quote
from uuid import uuid4
from fastapi import (
    Depends,
    FastAPI,
    File,
    Header,
    HTTPException,
    Request,
    UploadFile,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel, Field
from .config import Settings
from .db import ConflictError, Store
from .ingestion import ingest
from .provider import CohereProvider, ProviderError
from .rag import answer_question


class Message(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=2000)


class ChatInput(BaseModel):
    question: str = Field(min_length=1, max_length=1500)
    history: list[Message] = Field(
        default_factory=list, max_length=6
    )


class FeedbackInput(BaseModel):
    request_id: str = Field(min_length=36, max_length=36)
    useful: bool


def create_app(settings=None, store=None, provider=None):
    cfg = settings or Settings()
    database = store or Store(
        cfg.database_url, cfg.embedding_dimension
    )
    model = provider or CohereProvider(cfg)

    @asynccontextmanager
    async def lifespan(app):
        database.initialize()
        yield

    app = FastAPI(
        title="Horizon Numérique — RAG Cohere",
        version="0.2.0",
        lifespan=lifespan,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[
            s.strip()
            for s in cfg.allowed_origins.split(",")
            if s.strip()
        ],
        allow_methods=["GET", "POST", "DELETE"],
        allow_headers=["Content-Type", "X-Admin-Key"],
    )

    @app.middleware("http")
    async def request_headers(request, call_next):
        request.state.request_id = str(uuid4())
        response_headers = {
            "X-Request-ID": request.state.request_id,
            "X-Content-Type-Options": "nosniff",
        }
        length = request.headers.get("content-length")
        try:
            if (
                length
                and int(length) > cfg.max_upload_bytes + 65536
            ):
                return JSONResponse(
                    {"detail": "Corps de requête trop volumineux."},
                    status_code=413,
                    headers=response_headers,
                )
        except ValueError:
            return JSONResponse(
                {"detail": "Content-Length invalide."},
                status_code=400,
                headers=response_headers,
            )
        if (
            request.url.path.startswith("/admin/")
            and request.method != "OPTIONS"
        ):
            expected = cfg.admin_api_key.get_secret_value()
            received = request.headers.get("X-Admin-Key", "")
            if not expected:
                return JSONResponse(
                    {"detail": "Administration non configurée."},
                    status_code=503,
                    headers=response_headers,
                )
            if not secrets.compare_digest(
                received.encode(), expected.encode()
            ):
                return JSONResponse(
                    {"detail": "Accès administrateur refusé."},
                    status_code=401,
                    headers=response_headers,
                )
        if request.method in ("POST", "PUT", "PATCH"):
            data = bytearray()
            async for chunk in request.stream():
                if (
                    len(data) + len(chunk)
                    > cfg.max_upload_bytes + 65536
                ):
                    return JSONResponse(
                        {
                            "detail": (
                                "Corps de requête trop volumineux."
                            )
                        },
                        status_code=413,
                        headers=response_headers,
                    )
                data.extend(chunk)
            # Le corps borné est remis à la requête Starlette pour le parseur.
            request._body = bytes(data)
        start = time.monotonic()
        try:
            result = await call_next(request)
        except Exception:
            logging.error(
                "request_failed id=%s", request.state.request_id
            )
            result = JSONResponse(
                {
                    "detail": (
                        "Erreur interne. Contactez l’administrateur"
                        " avec l’identifiant de requête."
                    )
                },
                status_code=500,
            )
        result.headers["X-Request-ID"] = request.state.request_id
        result.headers["X-Content-Type-Options"] = "nosniff"
        logging.info(
            "request id=%s method=%s status=%s seconds=%.3f",
            request.state.request_id,
            request.method,
            result.status_code,
            time.monotonic() - start,
        )
        return result

    @app.exception_handler(ProviderError)
    async def provider_error(request, error):
        return JSONResponse(
            {"detail": str(error)},
            status_code=error.status,
            headers=(
                {"Retry-After": "60"} if error.status == 429 else {}
            ),
        )

    @app.exception_handler(ConflictError)
    async def conflict(request, error):
        return JSONResponse({"detail": str(error)}, status_code=409)

    def admin(x_admin_key: str = Header(default="")):
        expected = cfg.admin_api_key.get_secret_value()
        if not expected:
            raise HTTPException(
                503, "Administration non configurée."
            )
        if not secrets.compare_digest(
            x_admin_key.encode(), expected.encode()
        ):
            raise HTTPException(401, "Accès administrateur refusé.")

    def rate(request: Request):
        # Les en-têtes X-Forwarded-For ne sont jamais lus directement.
        ip = request.client.host if request.client else "unknown"
        if not database.allow_request(
            ip, cfg.chat_limit_per_minute
        ):
            raise HTTPException(
                429,
                "Trop de requêtes. Réessayez dans une minute.",
                headers={"Retry-After": "60"},
            )

    @app.get("/health")
    def health():
        return {
            **database.health(),
            "provider": "cohere",
            "cohere_configured": bool(
                cfg.cohere_api_key.get_secret_value()
            ),
            "embedding_model": cfg.cohere_embed_model,
            "embedding_dimension": cfg.embedding_dimension,
        }

    @app.get("/documents")
    def documents():
        return database.documents()

    @app.get("/documents/{document_id}/download")
    def download(document_id: str):
        doc = database.original(document_id)
        if not doc:
            raise HTTPException(404, "Document absent.")
        kind = (
            "application/pdf"
            if doc["filename"].lower().endswith(".pdf")
            else "text/plain; charset=utf-8"
        )
        return Response(
            bytes(doc["original"]),
            media_type=kind,
            headers={
                "Content-Disposition": (
                    "attachment; filename*=UTF-8''"
                    + quote(doc["filename"], safe="")
                )
            },
        )

    @app.post("/chat", dependencies=[Depends(rate)])
    def chat(body: ChatInput, request: Request):
        result = answer_question(
            database,
            model,
            cfg,
            body.question,
            [m.model_dump() for m in body.history],
        )
        database.receipt(request.state.request_id)
        return {**result, "request_id": request.state.request_id}

    @app.post(
        "/search", dependencies=[Depends(admin), Depends(rate)]
    )
    def search(body: ChatInput):
        vector = model.embed([body.question], "search_query")[0]
        return database.search(
            body.question, vector, cfg.embedding_identity
        )

    @app.post("/feedback", dependencies=[Depends(rate)])
    def feedback(body: FeedbackInput):
        if not database.feedback(body.request_id, body.useful):
            raise HTTPException(
                404, "Conversation inconnue ou expirée."
            )
        return {"status": "saved"}

    @app.post("/admin/documents", dependencies=[Depends(admin)])
    def upload(file: UploadFile = File(...)):
        data = file.file.read(cfg.max_upload_bytes + 1)
        file.file.close()
        try:
            return ingest(database, model, cfg, file.filename, data)
        except ValueError as error:
            raise HTTPException(422, str(error)) from error

    @app.post("/admin/seed", dependencies=[Depends(admin)])
    def seed():
        results = []
        for path in sorted(cfg.corpus_dir.glob("*")):
            if (
                path.is_file()
                and not path.is_symlink()
                and path.suffix.lower() in (".pdf", ".md", ".txt")
            ):
                results.append(
                    {
                        "filename": path.name,
                        **ingest(
                            database,
                            model,
                            cfg,
                            path.name,
                            path.read_bytes(),
                        ),
                    }
                )
        return {"documents": results}

    @app.delete(
        "/admin/documents/{document_id}",
        dependencies=[Depends(admin)],
    )
    def delete(document_id: str):
        if not database.delete_document(document_id):
            raise HTTPException(404, "Document absent.")
        return {"status": "deleted"}

    return app
