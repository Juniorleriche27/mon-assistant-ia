"""PostgreSQL en déploiement ; SQLite est un adaptateur local pour les tests."""

import hashlib
import json
import math
import re
import sqlite3
import time
import unicodedata
from contextlib import contextmanager
from pathlib import Path
from uuid import uuid4


class ConflictError(Exception):
    pass


def normalize(text):
    return "".join(
        c
        for c in unicodedata.normalize("NFKD", text.casefold())
        if not unicodedata.combining(c)
    )


STOP = set(
    "a au aux avec ce ces cette de des du dans en et est il je la"
    " le les leur ma me mes mon ne nos nous on ou par pas pour que"
    " quel quelle quels quelles qui se ses son sur un une vos vous"
    " y puis combien faut deja".split()
)


def terms(text):
    return set(re.findall(r"[a-z0-9]+", normalize(text))) - STOP


class Store:
    def __init__(self, url, dimension=1024):
        self.url, self.dimension = url, dimension
        self.sqlite = url.startswith("sqlite:///")

    @contextmanager
    def connect(self):
        if self.sqlite:
            filename = self.url.removeprefix("sqlite:///")
            Path(filename).parent.mkdir(parents=True, exist_ok=True)
            connection = sqlite3.connect(filename, timeout=15)
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA foreign_keys=ON")
        else:
            import psycopg
            from psycopg.rows import dict_row

            connection = psycopg.connect(
                self.url, row_factory=dict_row, connect_timeout=5
            )
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def run(self, conn, sql, args=()):
        return conn.execute(
            sql.replace("%s", "?") if self.sqlite else sql, args
        )

    def initialize(self):
        if not self.sqlite and self.dimension not in (
            256,
            512,
            1024,
            1536,
        ):
            raise ValueError(
                "Dimension de base non prise en charge."
            )
        blob = "BLOB" if self.sqlite else "BYTEA"
        vector = (
            "TEXT" if self.sqlite else f"vector({self.dimension})"
        )
        search = (
            ""
            if self.sqlite
            else (
                ", content_tsv tsvector GENERATED ALWAYS AS"
                " (to_tsvector('french', content)) STORED"
            )
        )
        statements = [
            f"""CREATE TABLE IF NOT EXISTS documents (
                id TEXT PRIMARY KEY, filename TEXT UNIQUE NOT NULL, content_hash TEXT NOT NULL,
                embedding_identity TEXT NOT NULL, original {blob} NOT NULL, chunk_count INTEGER NOT NULL)""",
            f"""CREATE TABLE IF NOT EXISTS chunks (
                id TEXT PRIMARY KEY, document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
                content TEXT NOT NULL, page INTEGER, section TEXT, embedding {vector} NOT NULL{search})""",
            (
                "CREATE INDEX IF NOT EXISTS chunks_doc_idx ON"
                " chunks(document_id)"
            ),
            (
                "CREATE TABLE IF NOT EXISTS feedback (id TEXT"
                " PRIMARY KEY, request_id TEXT NOT NULL, useful"
                " INTEGER NOT NULL, created_at BIGINT NOT NULL)"
            ),
            (
                "CREATE TABLE IF NOT EXISTS rate_limits (identity"
                " TEXT NOT NULL, bucket BIGINT NOT NULL, count"
                " INTEGER NOT NULL, PRIMARY KEY(identity,bucket))"
            ),
            (
                "CREATE TABLE IF NOT EXISTS request_receipts (id"
                " TEXT PRIMARY KEY, created_at BIGINT NOT NULL)"
            ),
        ]
        with self.connect() as conn:
            if not self.sqlite:
                self.run(
                    conn, "CREATE EXTENSION IF NOT EXISTS vector"
                )
            for statement in statements:
                self.run(conn, statement)
            if not self.sqlite:
                self.run(
                    conn,
                    "CREATE INDEX IF NOT EXISTS chunks_vector_idx"
                    " ON chunks USING hnsw (embedding"
                    " vector_cosine_ops)",
                )
                self.run(
                    conn,
                    "CREATE INDEX IF NOT EXISTS chunks_text_idx ON"
                    " chunks USING gin (content_tsv)",
                )
                actual = self.run(
                    conn,
                    "SELECT format_type(atttypid, atttypmod) AS t"
                    " FROM pg_attribute WHERE"
                    " attrelid='chunks'::regclass AND"
                    " attname='embedding'",
                ).fetchone()["t"]
                if actual != f"vector({self.dimension})":
                    raise ValueError(
                        "La dimension de la base diffère. Une"
                        " migration et une réindexation sont"
                        " nécessaires."
                    )

    def health(self):
        with self.connect() as conn:
            self.run(conn, "SELECT 1").fetchone()
            enabled = bool(
                self.sqlite
                or self.run(
                    conn,
                    "SELECT 1 FROM pg_extension WHERE"
                    " extname='vector'",
                ).fetchone()
            )
        return {
            "database_ok": True,
            "pgvector_enabled": enabled and not self.sqlite,
            "storage": (
                "sqlite-test" if self.sqlite else "postgresql"
            ),
        }

    def documents(self):
        with self.connect() as conn:
            return [
                dict(r)
                for r in self.run(
                    conn,
                    "SELECT"
                    " id,filename,content_hash,embedding_identity,chunk_count"
                    " FROM documents ORDER BY filename",
                ).fetchall()
            ]

    def document_by_name(self, name):
        with self.connect() as conn:
            r = self.run(
                conn,
                "SELECT"
                " id,filename,content_hash,embedding_identity,chunk_count"
                " FROM documents WHERE filename=%s",
                (name,),
            ).fetchone()
            return dict(r) if r else None

    def replace_document(
        self,
        filename,
        content_hash,
        identity,
        data,
        fragments,
        expected_hash,
    ):
        with self.connect() as conn:
            if self.sqlite:
                self.run(conn, "BEGIN IMMEDIATE")
            else:
                self.run(
                    conn,
                    "SELECT"
                    " pg_advisory_xact_lock(hashtextextended(%s,0))",
                    (filename,),
                )
            row = self.run(
                conn,
                "SELECT id,content_hash FROM documents WHERE"
                " filename=%s"
                + ("" if self.sqlite else " FOR UPDATE"),
                (filename,),
            ).fetchone()
            if (
                row["content_hash"] if row else None
            ) != expected_hash:
                raise ConflictError(
                    "Le document a changé pendant son indexation."
                    " Rechargez la liste."
                )
            doc_id = row["id"] if row else str(uuid4())
            if row:
                self.run(
                    conn,
                    "DELETE FROM chunks WHERE document_id=%s",
                    (doc_id,),
                )
                self.run(
                    conn,
                    "UPDATE documents SET"
                    " content_hash=%s,embedding_identity=%s,original=%s,chunk_count=%s"
                    " WHERE id=%s",
                    (
                        content_hash,
                        identity,
                        data,
                        len(fragments),
                        doc_id,
                    ),
                )
            else:
                self.run(
                    conn,
                    "INSERT INTO documents VALUES"
                    " (%s,%s,%s,%s,%s,%s)",
                    (
                        doc_id,
                        filename,
                        content_hash,
                        identity,
                        data,
                        len(fragments),
                    ),
                )
            for f in fragments:
                cast = "%s" if self.sqlite else "%s::vector"
                self.run(
                    conn,
                    "INSERT INTO"
                    " chunks(id,document_id,content,page,section,embedding)"
                    f" VALUES (%s,%s,%s,%s,%s,{cast})",
                    (
                        str(uuid4()),
                        doc_id,
                        f["content"],
                        f["page"],
                        f["section"],
                        json.dumps(f["embedding"]),
                    ),
                )
        return doc_id

    def delete_document(self, doc_id):
        with self.connect() as conn:
            return (
                self.run(
                    conn,
                    "DELETE FROM documents WHERE id=%s",
                    (doc_id,),
                ).rowcount
                > 0
            )

    def original(self, doc_id):
        with self.connect() as conn:
            row = self.run(
                conn,
                "SELECT filename,original FROM documents WHERE"
                " id=%s",
                (doc_id,),
            ).fetchone()
            return dict(row) if row else None

    def search(self, question, vector, identity, limit=5):
        if len(vector) != self.dimension or not all(
            math.isfinite(x) for x in vector
        ):
            raise ValueError("Vecteur de requête incompatible.")
        cols = "c.id,c.content,c.page,c.section,c.document_id,d.filename"
        with self.connect() as conn:
            incompatible = self.run(
                conn,
                "SELECT id FROM documents WHERE"
                " embedding_identity<>%s LIMIT 1",
                (identity,),
            ).fetchone()
            if incompatible:
                raise ConflictError(
                    "Le corpus doit être réindexé avec la"
                    " configuration embeddings actuelle."
                )
            if self.sqlite:
                all_rows = [
                    dict(r)
                    for r in self.run(
                        conn,
                        f"SELECT {cols}, c.embedding FROM chunks c"
                        " JOIN documents d ON c.document_id=d.id",
                    ).fetchall()
                ]
                qterms = terms(question)
                for r in all_rows:
                    emb = json.loads(r.pop("embedding"))
                    norm = math.sqrt(
                        sum(x * x for x in emb)
                        * sum(x * x for x in vector)
                    )
                    r["vector_score"] = (
                        sum(a * b for a, b in zip(emb, vector))
                        / norm
                        if norm
                        else 0
                    )
                    r["keyword_score"] = len(
                        qterms & terms(r["content"])
                    ) / max(1, len(qterms))
                vr = sorted(
                    all_rows,
                    key=lambda r: (-r["vector_score"], r["id"]),
                )[:25]
                kr = sorted(
                    (r for r in all_rows if r["keyword_score"] > 0),
                    key=lambda r: (-r["keyword_score"], r["id"]),
                )[:25]
            else:
                vs = json.dumps(vector)
                vr = [
                    dict(r)
                    for r in self.run(
                        conn,
                        f"""SELECT {cols}, 1-(c.embedding <=> %s::vector) AS vector_score,
                    ts_rank_cd(c.content_tsv,plainto_tsquery('french',%s)) AS keyword_score
                    FROM chunks c JOIN documents d ON c.document_id=d.id
                    ORDER BY c.embedding <=> %s::vector LIMIT 25""",
                        (vs, question, vs),
                    ).fetchall()
                ]
                kr = [
                    dict(r)
                    for r in self.run(
                        conn,
                        f"""SELECT {cols}, 1-(c.embedding <=> %s::vector) AS vector_score,
                    ts_rank_cd(c.content_tsv,plainto_tsquery('french',%s)) AS keyword_score
                    FROM chunks c JOIN documents d ON c.document_id=d.id
                    WHERE c.content_tsv @@ plainto_tsquery('french',%s)
                    ORDER BY keyword_score DESC,c.id LIMIT 25""",
                        (vs, question, question),
                    ).fetchall()
                ]
        merged = {}
        for rows in (vr, kr):
            for rank, row in enumerate(rows, 1):
                item = merged.setdefault(
                    row["id"], {**row, "rrf_score": 0.0}
                )
                item["rrf_score"] += 1 / (60 + rank)
        return sorted(
            merged.values(),
            key=lambda r: (-r["rrf_score"], r["id"]),
        )[:limit]

    def allow_request(self, identity, limit, timestamp=None):
        now = int(time.time() if timestamp is None else timestamp)
        bucket = now // 60
        identity = hashlib.sha256(identity.encode()).hexdigest()
        with self.connect() as conn:
            self.run(
                conn,
                "DELETE FROM rate_limits WHERE bucket<%s",
                (bucket - 2,),
            )
            row = self.run(
                conn,
                """INSERT INTO rate_limits(identity,bucket,count) VALUES(%s,%s,1)
                ON CONFLICT(identity,bucket) DO UPDATE SET count=rate_limits.count+1 RETURNING count""",
                (identity, bucket),
            ).fetchone()
            return row["count"] <= limit

    def receipt(self, request_id):
        now = int(time.time())
        with self.connect() as conn:
            self.run(
                conn,
                "DELETE FROM request_receipts WHERE created_at<%s",
                (now - 86400 * 7,),
            )
            self.run(
                conn,
                "INSERT INTO request_receipts VALUES(%s,%s)",
                (request_id, now),
            )

    def feedback(self, request_id, useful):
        with self.connect() as conn:
            if not self.run(
                conn,
                "SELECT id FROM request_receipts WHERE id=%s",
                (request_id,),
            ).fetchone():
                return False
            self.run(
                conn,
                "INSERT INTO feedback VALUES(%s,%s,%s,%s)",
                (
                    str(uuid4()),
                    request_id,
                    int(useful),
                    int(time.time()),
                ),
            )
        return True
