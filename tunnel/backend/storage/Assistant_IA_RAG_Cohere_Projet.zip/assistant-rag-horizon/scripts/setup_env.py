"""Crée la configuration locale, sans afficher de secret."""
from pathlib import Path
import secrets

root=Path(__file__).resolve().parents[1]
destination=root/'.env'
if destination.exists():
    raise SystemExit('La configuration existe déjà ; elle a été conservée.')
password=secrets.token_urlsafe(32)
text=(root/'.env.example').read_text()
text=text.replace('ADMIN_API_KEY=\n',f'ADMIN_API_KEY={secrets.token_urlsafe(32)}\n')
text=text.replace('POSTGRES_PASSWORD=\n',f'POSTGRES_PASSWORD={password}\n').replace('CHANGE_ME',password)
with destination.open('x') as file:file.write(text)
destination.chmod(0o600)
print('Configuration .env créée. Renseignez COHERE_API_KEY dans ce fichier local.')

