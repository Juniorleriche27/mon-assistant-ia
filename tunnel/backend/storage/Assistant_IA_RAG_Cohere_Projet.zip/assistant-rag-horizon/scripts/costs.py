import argparse
import json


def calculate(
    input_tokens,
    output_tokens,
    embedding_tokens,
    input_price,
    output_price,
    embedding_price,
    fixed=0,
):
    values = [
        input_tokens,
        output_tokens,
        embedding_tokens,
        input_price,
        output_price,
        embedding_price,
        fixed,
    ]
    if any(v < 0 for v in values):
        raise ValueError(
            "Les montants et volumes doivent être positifs."
        )
    chat = (
        input_tokens * input_price + output_tokens * output_price
    ) / 1_000_000
    embed = embedding_tokens * embedding_price / 1_000_000
    return {
        "chat": chat,
        "embeddings": embed,
        "fixed": fixed,
        "total": chat + embed + fixed,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description=(
            "Prix à renseigner dans une même devise, par million de"
            " jetons."
        )
    )
    for field in [
        "input_tokens",
        "output_tokens",
        "embedding_tokens",
        "input_price",
        "output_price",
        "embedding_price",
    ]:
        parser.add_argument(
            "--" + field.replace("_", "-"),
            type=float,
            required=True,
        )
    parser.add_argument("--fixed", type=float, default=0)
    print(
        json.dumps(calculate(**vars(parser.parse_args())), indent=2)
    )
