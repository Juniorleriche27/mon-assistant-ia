#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 2 ]; then
  printf 'Usage : %s fichier.sql.gz nom_nouvelle_base\n' "$0" >&2
  exit 1
fi
BACKUP_FILE="$(realpath -- "$1")"
TARGET="$2"
if [[ ! "$TARGET" =~ ^rag_restore_[a-zA-Z0-9_]+$ ]]; then
  printf 'La nouvelle base doit commencer par rag_restore_ et contenir uniquement lettres, chiffres et _.\n' >&2
  exit 1
fi
test -r "$BACKUP_FILE"
gzip -t "$BACKUP_FILE"
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
# createdb échoue si la cible existe : aucune base existante n'est écrasée.
docker compose -f docker-compose.prod.yml exec -T -e RESTORE_DB="$TARGET" db sh -c \
  'exec createdb -U "$POSTGRES_USER" "$RESTORE_DB"'
gunzip -c "$BACKUP_FILE" | docker compose -f docker-compose.prod.yml exec -T -e RESTORE_DB="$TARGET" db sh -c \
  'exec psql -X -v ON_ERROR_STOP=1 --single-transaction -U "$POSTGRES_USER" -d "$RESTORE_DB" -f -'
printf 'Restauration terminée dans la nouvelle base : %s\n' "$TARGET"

