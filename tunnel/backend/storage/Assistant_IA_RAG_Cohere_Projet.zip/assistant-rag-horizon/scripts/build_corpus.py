"""Reconstruit les documents fictifs livrés avec le livre (reportlab requis)."""
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
from xml.sax.saxutils import escape

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'corpus';OUT.mkdir(exist_ok=True)
DOCUMENTS={
 '01_catalogue_formations.pdf':[
  ('Analyse de Données - HN-DA-01',[
   'Le parcours Analyse de Données dure 8 semaines. Il couvre le nettoyage des données, les statistiques descriptives, Python, pandas, SQL et la présentation des résultats.',
   'Les participants doivent savoir utiliser un ordinateur et un tableur. Aucune expérience professionnelle en analyse de données n’est exigée.',
   'Le projet final consiste à analyser les ventes d’un commerce fictif et à expliquer les résultats dans un rapport.']),
  ('Automatisation & IA - HN-IA-01',[
   'Le parcours Automatisation & IA dure 6 semaines. Son programme couvre la cartographie des tâches, n8n, les API, les bases de Python et un assistant documentaire.',
   'Aucun prérequis en programmation n’est demandé pour Automatisation & IA. Les bases de Python sont enseignées progressivement pendant la formation.']),
  ('Développement Web - HN-WEB-01',[
   'Le parcours Développement Web dure 10 semaines. Il couvre HTML, CSS, JavaScript et une première application web.',
   'Le participant doit posséder un ordinateur portable. Les formations sont dispensées en français.'])],
 '02_tarifs_et_financements.pdf':[
  ('Tarifs du catalogue 2027',[
   'Analyse de Données : tarif total de 650 euros. Le paiement en trois tranches est de 220 euros, 220 euros puis 210 euros.',
   'Automatisation & IA : tarif total de 720 euros. Le paiement en trois tranches est de 240 euros par tranche.',
   'Développement Web : tarif total de 550 euros. Le paiement en deux tranches est de 275 euros par tranche.',
   'Les tarifs indiqués incluent 40 euros de frais administratifs d’inscription. Aucun supplément de 40 euros ne doit être ajouté au total annoncé.']),
  ('Modalités de paiement',[
   'La première tranche doit être réglée au plus tard 5 jours avant la date de début du parcours choisi. Les autres tranches sont versées au début des mois de formation suivants.',
   'Le centre accepte les virements bancaires et le paiement au secrétariat. La validation d’un paiement relève du secrétariat. L’assistant ne peut pas encaisser ni confirmer un règlement.',
   'Aucune réduction promotionnelle n’est prévue dans ce catalogue. Toute demande particulière doit être adressée au secrétariat.'])],
 '03_reglement_inscriptions.pdf':[
  ('Constituer le dossier',[
   'Pour s’inscrire, il faut fournir une copie de pièce d’identité, un formulaire d’inscription rempli et la preuve du paiement de la première tranche.',
   'Le dossier est étudié par le secrétariat. Une réponse de l’assistant ne vaut pas confirmation d’inscription. Les places sont confirmées par le secrétariat après validation du dossier.']),
  ('Annulation, remboursement et report',[
   'Une annulation reçue au moins 7 jours avant le début du parcours permet le remboursement des sommes versées, après déduction des 40 euros de frais administratifs. Pour une annulation reçue moins de 7 jours avant le début du parcours, aucun remboursement n’est prévu. Exception : en cas de force majeure justifiée, le secrétariat peut examiner un report sur une autre session ; ce report n’est pas automatique.',
   'Si le centre annule lui-même une session, il rembourse intégralement les sommes versées pour cette session.'])],
 '04_calendrier_sessions.pdf':[
  ('Horaires des cours',[
   'Les cours du soir ont lieu le lundi et le mercredi de 18h30 à 21h00. Les ateliers complémentaires du samedi se déroulent de 9h00 à 12h00.',
   'Les changements ponctuels d’horaires sont annoncés par le secrétariat. Le catalogue ne prévoit pas de cours réguliers le dimanche.']),
  ('Sessions et fermeture',[
   'La session Analyse de Données commence le 10 février 2027. La session Automatisation & IA commence le 17 février 2027. La session Développement Web commence le 3 mars 2027.',
   'Aucune session et aucun cours ne sont organisés en août. Le centre est fermé en août. Les dates d’éventuelles sessions ultérieures seront communiquées par le secrétariat.'])]}
styles=getSampleStyleSheet();styles['BodyText'].fontName='Helvetica';styles['BodyText'].fontSize=11;styles['BodyText'].leading=17
def footer(canvas,doc):
 canvas.setFont('Helvetica',9);canvas.setFillColor(colors.HexColor('#657184'))
 canvas.drawString(44,27,'Horizon Numérique - document fictif pour exercice')
 canvas.drawRightString(A4[0]-44,27,f'Page {doc.page}')
for name,pages in DOCUMENTS.items():
 story=[]
 for i,(title,paragraphs) in enumerate(pages):
  if i:story.append(PageBreak())
  story.extend([Paragraph('HORIZON NUMÉRIQUE',styles['Heading3']),Paragraph(escape(title),styles['Title']),Spacer(1,18)])
  for text in paragraphs:story.extend([Paragraph(escape(text),styles['BodyText']),Spacer(1,12)])
 SimpleDocTemplate(str(OUT/name),pagesize=A4,rightMargin=44,leftMargin=44,topMargin=44,bottomMargin=50).build(story,onFirstPage=footer,onLaterPages=footer)
(OUT/'05_faq_pratique.md').write_text('''# FAQ pratique - Horizon Numérique

## Contacter le centre
Le secrétariat répond du lundi au vendredi, de 8h00 à 17h00. L’adresse de démonstration est secretariat@horizon.example. Ce domaine est fictif ; il ne permet pas de contacter un vrai centre.

## Matériel et modalités
Les séances sont proposées en ligne. Il faut un ordinateur portable, une connexion Internet et un navigateur récent. Un téléphone seul ne permet pas de réaliser tous les exercices. Les supports de cours sont fournis en PDF.

## Attestation
Une attestation de suivi peut être délivrée si le participant assiste à au moins 80 % des séances et si son projet final est validé. Cette attestation n’est pas présentée comme un diplôme d’État.

## Inscription
L’assistant informe à partir des documents. Le secrétariat valide les inscriptions, les règlements et les demandes de report. L’assistant ne peut ni réserver une place ni effectuer un paiement.
''',encoding='utf-8')
print(f'{len(DOCUMENTS)+1} documents fictifs générés.')

