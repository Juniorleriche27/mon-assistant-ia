"""Intègre des extraits du code livré dans le manuscrit pédagogique."""
from pathlib import Path
import ast
import json
from textwrap import dedent

ROOT=Path(__file__).resolve().parents[1]
text=(ROOT/'book/manuscrit_source.md').read_text()

def excerpt(path,name):
    content=(ROOT/path).read_text()
    node=next(n for n in ast.walk(ast.parse(content)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.name==name)
    start=min([node.lineno]+[d.lineno for d in getattr(node,'decorator_list',[])])
    return dedent('\n'.join(content.splitlines()[start-1:node.end_lineno]))

def code(content,language='python'):
    return '\n```'+language+'\n'+content+'\n```\n'

def insert_before(chapter,addition):
    global text
    needle='## Chapitre '+str(chapter)+' -'
    position=text.index(needle)
    # Les titres de partie restent avant le chapitre qu’ils introduisent.
    last_part=text.rfind('\n# Partie ',0,position)
    if last_part>text.rfind('\n## Chapitre ',0,position):position=last_part
    text=text[:position]+addition+'\n'+text[position:]

additions={
 4:('### Atelier de code - La configuration du serveur\n\nFichier : `backend/app/config.py`. Les valeurs sont validées dès la construction des paramètres. Le type SecretStr évite un affichage accidentel dans la représentation de l’objet.\n'+code(excerpt('backend/app/config.py','Settings'))+'\nContrôle : démarrer le service puis consulter `/health`. Une dimension comme 768 est refusée par cette configuration Embed v4.\n'),
 5:('### Atelier de code - Lire un document et conserver sa provenance\n\nFichier : `backend/app/ingestion.py`. L’extraction vérifie le contenu et conserve la page ou la section. Observez le moment où ces métadonnées sont attachées aux fragments.\n'+code(excerpt('backend/app/ingestion.py','extract_fragments'))+'\nVérification ciblée, depuis la racine du projet :\n'+code('python -m unittest tests.test_backend.BackendTests.test_update_failure_rolls_back_old_corpus -v','bash')),
 6:('### Atelier de code - Fusionner les résultats\n\nFichier : `backend/app/db.py`, méthode `Store.search`. Comparez les deux listes puis la boucle de fusion ; les contributions RRF portent sur le rang et non sur les scores bruts.\n'+code(excerpt('backend/app/db.py','search'))),
 7:('### Atelier de code - Accepter une réponse et ses références\n\nFichier : `backend/app/rag.py`. La vérification des identifiants se fait après la génération et avant la construction des sources affichées.\n'+code(excerpt('backend/app/rag.py','answer_question'))+'\nContrôle ciblé :\n'+code('python -m unittest tests.test_backend.BackendTests.test_invented_source_is_rejected -v','bash')),
 8:('### Atelier de code - La route de discussion\n\nFichier : `backend/app/main.py`. Le schéma borne les entrées et la route relie le moteur documentaire au contrat HTTP.\n'+code(excerpt('backend/app/main.py','ChatInput'))+code(excerpt('backend/app/main.py','chat'))+'\nL’identifiant enregistré sert au retour utilisateur sans exiger de conserver le texte complet dans les journaux.\n'),
 9:('### Atelier de code - Un appel depuis l’interface\n\nFichier : `frontend/app/api.ts`. Une erreur HTTP est transformée en message lisible. Le navigateur utilise le chemin public `/api`.\n'+code((ROOT/'frontend/app/api.ts').read_text(),'typescript')+'\nContrôle de compilation depuis `frontend/` :\n'+code('npm ci\nnpm run build','bash')),
 10:('### Atelier de code - Lire un indicateur automatique\n\nFichier : `eval/run_eval.py`. La fonction ci-dessous vérifie le statut, plusieurs groupes d’éléments et les fichiers cités. La lecture humaine porte ensuite sur le sens et le passage exact.\n'+code(excerpt('eval/run_eval.py','judge'))+'\nExemple d’attente pour une demande ambiguë :\n'+code(json.dumps({'question':'Combien coûte la formation ?','expected_status':'clarify','required_sources':[],'required_groups':[['quelle formation','quel parcours','préciser']]},ensure_ascii=False,indent=2),'json')),
 11:('### Atelier de code - Vérifier l’administration et partager le débit\n\nFichier : `backend/app/main.py`, dépendance de contrôle des opérations. Le middleware effectue également un contrôle préalable pour ne pas lire un fichier volumineux non autorisé.\n'+code(excerpt('backend/app/main.py','admin'))+'\nFichier : `backend/app/db.py`, compteur partagé entre workers. Le test utilise deux instances de stockage pour vérifier cette propriété.\n'+code(excerpt('backend/app/db.py','allow_request'))),
 12:('### Atelier de code - Sauvegarder et restaurer\n\nCes scripts sont destinés à Bash, sur le serveur ou dans un environnement adapté. Les noms de services proviennent du fichier Compose de production.\n\nFichier : `scripts/backup_db.sh`.\n'+code((ROOT/'scripts/backup_db.sh').read_text(),'bash')+'\nFichier : `scripts/restore_db.sh`.\n'+code((ROOT/'scripts/restore_db.sh').read_text(),'bash')+'\nLes tests des scripts simulent Docker et les erreurs. Une répétition avec un vrai serveur et une vraie base reste nécessaire avant une livraison.\n')}
for chapter,addition in additions.items():insert_before(chapter,addition)
text=text.replace('python -m unittest tests.test_backend.BackendTests.test_update_failure_rolls_back_old_corpus -v','python -m unittest discover -s tests -v')
text=text.replace('python -m unittest tests.test_backend.BackendTests.test_invented_source_is_rejected -v','python -m unittest discover -s tests -v')
needle='## Conclusion - Réutiliser la méthode'
addition='''### Atelier de code - Calculer une hypothèse budgétaire

Fichier : `scripts/costs.py`. Les volumes et prix sont séparés pour préserver les unités.
'''+code(excerpt('scripts/costs.py','calculate'))+'''
L’exemple hypothétique du chapitre s’exécute ainsi :
'''+code('python scripts/costs.py --input-tokens 2000000 --output-tokens 500000 --embedding-tokens 1000000 --input-price 1 --output-price 2 --embedding-price 0.1 --fixed 10','bash')+'''
Le total attendu est 13,1 unités monétaires. Remplacez ces prix d’exercice par les prix vérifiés de votre fournisseur pour un devis réel.

'''
text=text.replace(needle,addition+needle)
text=text.replace('python scripts/costs.py --input-tokens 2000000 --output-tokens 500000 --embedding-tokens 1000000 --input-price 1 --output-price 2 --embedding-price 0.1 --fixed 10',
                  'python scripts/costs.py \\\n+  --input-tokens 2000000 --output-tokens 500000 \\\n+  --embedding-tokens 1000000 --input-price 1 \\\n+  --output-price 2 --embedding-price 0.1 --fixed 10')
text=text.replace(chr(10)+'+  --',chr(10)+'  --')
destination=ROOT/'book/Manuscrit_Complet_Assistant_IA_RAG.md'
destination.write_text(text,encoding='utf-8')
print(json.dumps({'file':str(destination),'words':len(text.split()),'chapters':text.count('## Chapitre ')},ensure_ascii=False))
