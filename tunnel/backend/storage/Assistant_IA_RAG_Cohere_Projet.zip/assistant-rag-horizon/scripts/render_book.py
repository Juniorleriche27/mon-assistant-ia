"""Met en page le manuscrit en PDF A5, avec sommaire et code du projet."""
from pathlib import Path
import re
import os
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A5
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import BaseDocTemplate, Frame, PageTemplate, Paragraph, Spacer, PageBreak, Preformatted, Table, TableStyle, Flowable
from reportlab.platypus.tableofcontents import TableOfContents

ROOT=Path(__file__).resolve().parents[1]
OUTPUT=ROOT/'book/Creer_et_livrer_son_premier_assistant_IA_Cohere.pdf'
FONTS=Path(os.environ.get('BOOK_FONT_DIR',ROOT/'assets/fonts'))
for name,filename in [('Text','DejaVuSans.ttf'),('TextBold','DejaVuSans-Bold.ttf'),('Serif','DejaVuSerif.ttf'),('Code','DejaVuSansMono.ttf')]:
    file=FONTS/filename
    if not file.exists():raise SystemExit('Installer les polices DejaVu ou adapter FONTS dans ce script.')
    pdfmetrics.registerFont(TTFont(name,str(file)))
pdfmetrics.registerFontFamily('Text',normal='Text',bold='TextBold',italic='Text',boldItalic='TextBold')
INK=colors.HexColor('#1c2635');BLUE=colors.HexColor('#3157c8');MUTED=colors.HexColor('#667184')
WIDTH,HEIGHT=A5
MARGIN=42
CONTENT=WIDTH-2*MARGIN
styles={
 'body':ParagraphStyle('body',fontName='Text',fontSize=9.6,leading=15.0,textColor=INK,spaceAfter=8,splitLongWords=True),
 'h1':ParagraphStyle('h1',fontName='Serif',fontSize=23,leading=29,textColor=INK,spaceAfter=24,keepWithNext=True),
 'h2':ParagraphStyle('h2',fontName='Serif',fontSize=18.5,leading=24,textColor=BLUE,spaceAfter=18,keepWithNext=True),
 'h3':ParagraphStyle('h3',fontName='TextBold',fontSize=11.2,leading=16,textColor=INK,spaceBefore=16,spaceAfter=10,keepWithNext=True),
 'code':ParagraphStyle('code',fontName='Code',fontSize=7.4,leading=10,textColor=INK,backColor=colors.HexColor('#eef1f7'),borderPadding=7,spaceBefore=8,spaceAfter=12),
 'cell':ParagraphStyle('cell',fontName='Text',fontSize=8,leading=11,textColor=INK,spaceAfter=0,splitLongWords=True),
 'small':ParagraphStyle('small',fontName='Text',fontSize=8.5,leading=13,textColor=MUTED,spaceAfter=8),
}

def clean(text):
    return text.replace('\u2011','-').replace('\u2014','-').replace('\u2013','-').replace('\u00a0',' ')

def inline(text):
    text=escape(clean(text))
    text=re.sub(r'`([^`]+)`',r'<font name="Code" size="8.3">\1</font>',text)
    text=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',text)
    return text

class Cover(Flowable):
    def __init__(self):super().__init__();self.width=CONTENT;self.height=HEIGHT-2*MARGIN-12
    def draw(self):
        c=self.canv;h=self.height
        c.setFillColor(BLUE);c.rect(0,h-10,46,4,fill=1,stroke=0)
        c.setFont('TextBold',8);c.drawString(0,h-38,'GUIDE PRATIQUE / ÉDITION COHERE')
        c.setFillColor(INK);c.setFont('Serif',27)
        for i,line in enumerate(['Créer et livrer','son premier','assistant IA']):c.drawString(0,h-107-i*37,line)
        c.setFont('Text',11)
        for i,line in enumerate(['Des documents de l’entreprise','au déploiement.','Un projet RAG complet et son code.']):c.drawString(0,h-263-i*21,line)
        c.setStrokeColor(colors.HexColor('#d9deea'));c.line(0,90,CONTENT,90)
        c.setFont('TextBold',12);c.drawString(0,62,'LAMADOKOU Yayra')
        c.setFont('Text',8);c.setFillColor(MUTED);c.drawString(0,39,'Horizon Numérique - projet pédagogique fictif')

class CircuitDiagram(Flowable):
    def __init__(self):
        super().__init__();self.width=CONTENT;self.height=176
    def draw(self):
        c=self.canv
        def box(x,y,label,detail):
            c.setFillColor(colors.HexColor('#eef2fd'));c.setStrokeColor(colors.HexColor('#c6d2f5'))
            c.roundRect(x,y,96,40,5,fill=1,stroke=1)
            c.setFillColor(INK);c.setFont('TextBold',8);c.drawCentredString(x+48,y+24,label)
            c.setFont('Text',6.8);c.drawCentredString(x+48,y+11,detail)
        def arrow(x1,y1,x2,y2):
            c.setStrokeColor(BLUE);c.setFillColor(BLUE);c.setLineWidth(.8);c.line(x1,y1,x2,y2)
            import math
            angle=math.atan2(y2-y1,x2-x1);size=4
            p=c.beginPath();p.moveTo(x2,y2)
            p.lineTo(x2-size*math.cos(angle-.45),y2-size*math.sin(angle-.45))
            p.lineTo(x2-size*math.cos(angle+.45),y2-size*math.sin(angle+.45));p.close();c.drawPath(p,fill=1,stroke=0)
        c.setFont('TextBold',8);c.setFillColor(BLUE);c.drawString(0,160,'1 / Préparer les documents')
        box(0,106,'Documents','originaux validés');box(119,106,'Fragments','texte + provenance');box(238,106,'Base','vecteurs + texte')
        arrow(98,126,116,126);arrow(217,126,235,126)
        c.setFont('TextBold',8);c.setFillColor(BLUE);c.drawString(0,78,'2 / Traiter une question')
        box(0,17,'Question','embedding de requête');box(119,17,'Recherche','passages pertinents');box(238,17,'Cohere','réponse + sources')
        arrow(98,37,116,37);arrow(217,37,235,37);arrow(285,104,167,59)

class Book(BaseDocTemplate):
    def __init__(self,path):
        super().__init__(str(path),pagesize=A5,leftMargin=MARGIN,rightMargin=MARGIN,topMargin=MARGIN+8,bottomMargin=MARGIN,
                         title='Créer et livrer son premier assistant IA - édition Cohere',author='LAMADOKOU Yayra')
        frame=Frame(MARGIN,MARGIN,CONTENT,HEIGHT-2*MARGIN-8,id='normal',leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)
        self.addPageTemplates(PageTemplate(id='body',frames=frame,onPage=self.page_decor))
        self.bookmark_count=0
    def beforeDocument(self):
        self.bookmark_count=0
    def page_decor(self,c,doc):
        if doc.page==1:return
        c.saveState();c.setFillColor(MUTED);c.setFont('Text',6.8)
        c.drawString(MARGIN,HEIGHT-25,'CRÉER ET LIVRER SON PREMIER ASSISTANT IA')
        c.setStrokeColor(colors.HexColor('#d9deea'));c.line(MARGIN,HEIGHT-33,WIDTH-MARGIN,HEIGHT-33)
        c.drawString(MARGIN,24,'ÉDITION COHERE');c.drawRightString(WIDTH-MARGIN,24,str(doc.page));c.restoreState()
    def afterFlowable(self,flowable):
        if isinstance(flowable,Paragraph) and hasattr(flowable,'toc_level'):
            self.bookmark_count+=1;key=f'section-{self.bookmark_count}'
            self.canv.bookmarkPage(key)
            self.notify('TOCEntry',(flowable.toc_level,flowable.getPlainText(),self.page,key))

def code_block(lines):
    wrapped=[]
    for line in lines:
        line=clean(line).expandtabs(4)
        if not line:wrapped.append('');continue
        while pdfmetrics.stringWidth(line,'Code',7.4)>CONTENT-16:
            n=len(line)
            while n>1 and pdfmetrics.stringWidth(line[:n],'Code',7.4)>CONTENT-16:n-=1
            wrapped.append(line[:n]);line='    '+line[n:]
        wrapped.append(line)
    return Preformatted('\n'.join(wrapped),styles['code'])

def main():
    source=(ROOT/'book/Manuscrit_Complet_Assistant_IA_RAG.md').read_text()
    # La couverture remplace les premières lignes de titre et la signature.
    source=source[source.index('## Ouverture'):]
    story=[Cover(),PageBreak(),Paragraph('Sommaire',styles['h1'])]
    toc=TableOfContents();toc.levelStyles=[ParagraphStyle('toc0',fontName='TextBold',fontSize=9,leading=14,leftIndent=0,firstLineIndent=0,spaceBefore=9,textColor=BLUE),ParagraphStyle('toc1',fontName='Text',fontSize=8.5,leading=13,leftIndent=9,firstLineIndent=0,spaceBefore=5,textColor=INK)]
    story.extend([toc,PageBreak()])
    lines=source.splitlines();i=0
    while i<len(lines):
        line=lines[i].strip()
        if not line:i+=1;continue
        if line.startswith('```'):
            i+=1;block=[]
            while i<len(lines) and not lines[i].strip().startswith('```'):block.append(lines[i]);i+=1
            story.append(code_block(block));i+=1;continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                cells=[x.strip() for x in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r'[-: ]+',c or '-') for c in cells):rows.append([Paragraph(inline(c),styles['cell']) for c in cells])
                i+=1
            if rows:
                widths=[CONTENT*.28,CONTENT*.72] if len(rows[0])==2 else [CONTENT/len(rows[0])]*len(rows[0])
                table=Table(rows,colWidths=widths,repeatRows=1,hAlign='LEFT')
                table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e5ebfc')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.6,BLUE),('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#dde2eb')),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
                story.extend([table,Spacer(1,12)])
            continue
        heading=re.match(r'^(#{1,3})\s+(.+)',line)
        if heading:
            level=len(heading.group(1));title=heading.group(2)
            if level<=2:
                if story and not isinstance(story[-1],PageBreak):story.append(PageBreak())
                p=Paragraph(inline(title),styles['h1' if level==1 else 'h2'])
                p.toc_level=0 if level==1 else 1;story.append(p)
                if title.startswith('Chapitre 2 -'):
                    story.extend([CircuitDiagram(),Paragraph('Deux circuits reliés par un corpus documenté. La recherche fournit les passages au modèle de génération.',styles['small'])])
            else:story.append(Paragraph(inline(title),styles['h3']))
            i+=1;continue
        if re.match(r'^[-*]\s',line) or re.match(r'^\d+\.\s',line):
            story.append(Paragraph(inline(line),styles['body']));i+=1;continue
        paragraph=[line];i+=1
        while i<len(lines) and lines[i].strip() and not re.match(r'^(#{1,3}\s|```|\||[-*]\s|\d+\.\s)',lines[i].strip()):
            paragraph.append(lines[i].strip());i+=1
        story.append(Paragraph(inline(' '.join(paragraph)),styles['body']))
    Book(OUTPUT).multiBuild(story)
    print(OUTPUT)

if __name__=='__main__':main()
