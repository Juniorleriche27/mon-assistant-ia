#!/usr/bin/env bash
set -euo pipefail
umask 077
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
mkdir -p backups
STAMP="$(date -u +%Y%m%d_%H%M%S)_$$"
OUT_FILE="$ROOT/backups/rag_horizon_${STAMP}.sql.gz"
TEMP_FILE="${OUT_FILE}.partial"
trap 'rm -f -- "$TEMP_FILE"' EXIT
docker compose -f docker-compose.prod.yml exec -T db sh -c \
  'exec pg_dump --no-owner --no-privileges -U "$POSTGRES_USER" "$POSTGRES_DB"' | gzip > "$TEMP_FILE"
gzip -t "$TEMP_FILE"
mv -- "$TEMP_FILE" "$OUT_FILE"
printf 'Sauvegarde créée : %s\n' "$OUT_FILE"

