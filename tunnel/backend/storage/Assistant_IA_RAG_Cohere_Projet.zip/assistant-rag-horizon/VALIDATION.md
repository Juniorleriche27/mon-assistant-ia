# Validation de l’édition Cohere

Date : 18 novembre 2026.

## Livrables

- Manuscrit : 11043 mots, 12 chapitres, exercices et extraits issus du code fourni.
- PDF A5 : 68 pages, sommaire, schéma du RAG et code.
- Projet : API FastAPI, interface Next.js, stockage PostgreSQL/pgvector, adaptateur SQLite local, quatre PDF fictifs et une FAQ.
- Évaluation métier : 35 questions prêtes, avec statut et sources attendus.

## Contrôles réellement effectués

| Contrôle | Résultat et périmètre |
|---|---|
| Tests logiciels Python | 46 tests réussis. SQLite, doubles de test, transport HTTP Cohere simulé. |
| Administration et entrées | Accès refusé sans clé, pré-vérification CORS, tailles et formats, historique validé. |
| Documents | Indexation, absence de recalcul pour un doublon, remplacement atomique, annulation sur échec et suppression. |
| Sources | Sources construites depuis la base ; identifiants inventés et réponses sans source rejetés. |
| Cohere HTTP | Contrats Chat v2 et Embed v2, types search_document/search_query, dimension, lots, quotas et réponses invalides testés sans réseau. |
| Sauvegarde/restauration | Syntaxe Bash et scénarios de réussite/échec avec Docker simulé. Aucune base réelle restaurée. |
| Frontend | Compilation de production et validation TypeScript réussies avec Next.js 16.4.6 et React 19.3.1. |
| Audit npm production | Aucun avis de vulnérabilité retourné lors du contrôle. |
| Interface en navigateur | Discussion, consultation de sources, liste des documents et absence de débordement horizontal à 390 px. Fournisseur de test simulé. |
| PDF | Couverture, sommaire, schéma, extraits et tableau relus visuellement ; contrôle de débordement du texte. |
| Configurations Compose | Fichiers YAML analysés et structure des services vérifiée. |

## Contrôles restant à effectuer avec l’environnement cible

- Renseigner une clé Cohere sur la machine du lecteur et exécuter la véritable indexation puis les 35 questions. Aucun appel réel aux modèles n’a été effectué pendant ces contrôles.
- Démarrer les conteneurs Docker et tester PostgreSQL/pgvector : Docker et ce service n’étaient pas disponibles dans l’environnement de préparation. L’adaptateur PostgreSQL et ses index ne sont donc pas validés en exécution ici.
- Vérifier DNS, HTTPS, adresses de proxy, sauvegarde et restauration avec le serveur réel.
- Mesurer les temps de réponse, les jetons et la qualité réelle des modèles avant de présenter un résultat de réception client.

## Conditions de lecture des résultats

Une suite de tests passée confirme les cas logiciels testés. Elle ne remplace pas une évaluation des modèles distants. Les scripts d’évaluation calculent des indicateurs ; la grille manuelle vérifie le sens, les conditions, les montants et les passages cités. Le PDF est une première version développée de travail, à relire avec les résultats de ces essais avant publication commerciale.
